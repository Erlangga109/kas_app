<?php
include 'koneksi.php';
echo "Koneksi ke database berhasil!";
?>
