<?php
include 'koneksi.php';

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_baru = $_POST['nama_baru'];

    if (empty($nama_baru)) {
        echo "<script>alert('Nama baru tidak boleh kosong!'); window.history.back();</script>";
    } else {
        $stmt = $conn->prepare("UPDATE kas SET nama = ? WHERE id = ?");
        $stmt->bind_param("si", $nama_baru, $id);

        if ($stmt->execute()) {
            echo "<script>alert('Nama berhasil diubah!'); window.location='index.php';</script>";
        } else {
            echo "<script>alert('Gagal mengubah nama: " . $conn->error . "'); window.history.back();</script>";
        }
        $stmt->close();
    }
} else {
    $stmt = $conn->prepare("SELECT nama FROM kas WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $nama_lama = $row['nama'];
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Nama</title>
    <link rel="stylesheet" href="assets/style.css?v=1.1">
</head>
<body>
<div class="container">
    <h1>Edit Nama</h1>

    <form action="edit.php?id=<?= $id; ?>" method="POST" class="form">
        <label>Nama Lama:</label>
        <input type="text" value="<?= htmlspecialchars($nama_lama); ?>" disabled>
        <label>Nama Baru:</label>
        <input type="text" name="nama_baru" required>
        <button type="submit" class="btn-submit">Simpan Perubahan</button>
    </form>
</div>
</body>
</html>
