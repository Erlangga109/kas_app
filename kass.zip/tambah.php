<?php
include 'koneksi.php';

$nama   = $_POST['nama'];
$jumlah = $_POST['jumlah'];

if (empty($nama) || empty($jumlah)) {
    echo "<script>alert('Nama dan jumlah harus diisi!'); window.history.back();</script>";
    exit;
}

// Cek apakah nama sudah ada
$stmt = $conn->prepare("SELECT jumlah FROM kas WHERE nama = ?");
$stmt->bind_param("s", $nama);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Jika nama sudah ada, update jumlahnya
    $row = $result->fetch_assoc();
    $jumlah_lama = $row['jumlah'];
    $jumlah_baru = $jumlah_lama + $jumlah;

    $stmt_update = $conn->prepare("UPDATE kas SET jumlah = ? WHERE nama = ?");
    $stmt_update->bind_param("is", $jumlah_baru, $nama);

    if ($stmt_update->execute()) {
        echo "<script>alert('Data berhasil diperbarui!'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data: " . $conn->error . "'); window.history.back();</script>";
    }
    $stmt_update->close();
} else {
    // Jika nama belum ada, insert data baru
    $stmt_insert = $conn->prepare("INSERT INTO kas (nama, jumlah) VALUES (?, ?)");
    $stmt_insert->bind_param("si", $nama, $jumlah);

    if ($stmt_insert->execute()) {
        echo "<script>alert('Data berhasil disimpan!'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan data: " . $conn->error . "'); window.history.back();</script>";
    }
    $stmt_insert->close();
}

$stmt->close();
$conn->close();
?>
