document.addEventListener('DOMContentLoaded', function() {
    const generateBtn = document.getElementById('generate-qris');
    const namaInput = document.getElementById('qris-nama');
    const jumlahInput = document.getElementById('qris-jumlah');
    const qrisDisplay = document.getElementById('qris-display');

    if (!generateBtn) return; // Jika halaman belum punya form QRIS

    generateBtn.addEventListener('click', function() {
        const nama = namaInput.value.trim();
        const jumlah = jumlahInput.value;

        if (nama === '' || jumlah === '') {
            alert('Mohon isi nama dan pilih jumlah pembayaran!');
            return;
        }

        // Buat data QRIS (JSON)
        const data = {
            nama: nama,
            jumlah: jumlah,
            keterangan: 'Pembayaran Kas',
            tanggal: new Date().toLocaleString('id-ID')
        };

        // Tampilkan gambar QRIS statis
        qrisDisplay.innerHTML = '<img src="assets/qris.png" alt="Kode QRIS" style="width:200px; height:auto;">';

        // Kirim data ke PHP (tanpa reload halaman)
        fetch('tambah.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ nama: nama, jumlah: jumlah })
        })
        .then(response => response.text())
        .then(res => {
            console.log('Server response:', res);
            // Tampilkan notifikasi di layar (tidak pakai alert)
            const notif = document.createElement('div');
            notif.textContent = "✅ Data tersimpan! QR siap discan.";
            notif.style.background = "#4CAF50";
            notif.style.color = "white";
            notif.style.padding = "10px";
            notif.style.marginTop = "10px";
            notif.style.borderRadius = "5px";
            qrisDisplay.appendChild(notif);
        })
        .catch(err => {
            console.error(err);
            alert('Gagal menyimpan data ke server!');
        });
    });
});
